<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ══════════════════════════════════════════════════════════════════════════════
// ENQUEUE SCRIPTS & STYLES
// ══════════════════════════════════════════════════════════════════════════════
function travzo_enqueue_scripts() {
    wp_enqueue_style(
        'travzo-style',
        get_stylesheet_uri(),
        array(),
        '1.0.0'
    );

    $main_css = get_template_directory() . '/assets/css/main.css';
    wp_enqueue_style(
        'travzo-main-style',
        get_template_directory_uri() . '/assets/css/main.css',
        array(),
        file_exists( $main_css ) ? filemtime( $main_css ) : '1.0.0'
    );

    $main_js = get_template_directory() . '/assets/js/main.js';
    if ( file_exists( $main_js ) ) {
        wp_enqueue_script(
            'travzo-main-script',
            get_template_directory_uri() . '/assets/js/main.js',
            array(),
            filemtime( $main_js ),
            true
        );
    }
}
add_action( 'wp_enqueue_scripts', 'travzo_enqueue_scripts' );

// ══════════════════════════════════════════════════════════════════════════════
// THEME SUPPORT
// ══════════════════════════════════════════════════════════════════════════════
function travzo_theme_setup() {
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'html5', [
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
    ] );

    register_nav_menus( [
        'primary-menu' => __( 'Primary Menu', 'travzo' ),
        'footer-menu'  => __( 'Footer Menu', 'travzo' ),
    ] );
}
add_action( 'after_setup_theme', 'travzo_theme_setup' );

// ══════════════════════════════════════════════════════════════════════════════
// IMAGE SIZES
// ══════════════════════════════════════════════════════════════════════════════
function travzo_add_image_sizes() {
    add_image_size( 'package-card', 600, 400, true );
    add_image_size( 'package-hero', 1440, 600, true );
}
add_action( 'after_setup_theme', 'travzo_add_image_sizes' );

// ══════════════════════════════════════════════════════════════════════════════
// WIDGET AREAS
// ══════════════════════════════════════════════════════════════════════════════
function travzo_register_widgets() {
    register_sidebar( [
        'name'          => __( 'Sidebar', 'travzo' ),
        'id'            => 'sidebar',
        'description'   => __( 'Main sidebar widget area.', 'travzo' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ] );

    register_sidebar( [
        'name'          => __( 'Footer Widgets', 'travzo' ),
        'id'            => 'footer-widgets',
        'description'   => __( 'Footer widget area.', 'travzo' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ] );
}
add_action( 'widgets_init', 'travzo_register_widgets' );

// ══════════════════════════════════════════════════════════════════════════════
// CUSTOM POST TYPE: PACKAGE
// ══════════════════════════════════════════════════════════════════════════════
function travzo_register_package_cpt() {
    $labels = [
        'name'               => __( 'Packages', 'travzo' ),
        'singular_name'      => __( 'Package', 'travzo' ),
        'add_new'            => __( 'Add New', 'travzo' ),
        'add_new_item'       => __( 'Add New Package', 'travzo' ),
        'edit_item'          => __( 'Edit Package', 'travzo' ),
        'new_item'           => __( 'New Package', 'travzo' ),
        'view_item'          => __( 'View Package', 'travzo' ),
        'search_items'       => __( 'Search Packages', 'travzo' ),
        'not_found'          => __( 'No packages found', 'travzo' ),
        'not_found_in_trash' => __( 'No packages found in trash', 'travzo' ),
        'menu_name'          => __( 'Packages', 'travzo' ),
    ];

    register_post_type( 'package', [
        'labels'       => $labels,
        'public'       => true,
        'has_archive'  => true,
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'rewrite'      => [ 'slug' => 'packages' ],
        'show_in_rest' => true,
    ] );
}
add_action( 'init', 'travzo_register_package_cpt' );

// ══════════════════════════════════════════════════════════════════════════════
// WORDPRESS CUSTOMIZER – TRAVZO SETTINGS PANEL
// ══════════════════════════════════════════════════════════════════════════════
add_action( 'customize_register', function ( $wp_customize ) {

    // ── Main Panel ────────────────────────────────────────────────────────────
    $wp_customize->add_panel( 'travzo_panel', [
        'title'    => 'Travzo Settings',
        'priority' => 10,
    ] );

    // ── SECTION: Contact Information ─────────────────────────────────────────
    $wp_customize->add_section( 'travzo_contact', [
        'title' => 'Contact Information',
        'panel' => 'travzo_panel',
    ] );
    $contact_fields = [
        'travzo_phone'    => 'Phone Number',
        'travzo_email'    => 'Email Address',
        'travzo_whatsapp' => 'WhatsApp Number (digits only, e.g. 919940882200)',
        'travzo_address'  => 'Office Address',
        'travzo_hours'    => 'Working Hours',
    ];
    foreach ( $contact_fields as $key => $label ) {
        $wp_customize->add_setting( $key, [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $key, [ 'label' => $label, 'section' => 'travzo_contact', 'type' => 'text' ] );
    }

    // ── SECTION: Social Media ─────────────────────────────────────────────────
    $wp_customize->add_section( 'travzo_social', [
        'title' => 'Social Media Links',
        'panel' => 'travzo_panel',
    ] );
    $social_fields = [
        'travzo_instagram' => 'Instagram URL',
        'travzo_facebook'  => 'Facebook URL',
        'travzo_youtube'   => 'YouTube URL',
    ];
    foreach ( $social_fields as $key => $label ) {
        $wp_customize->add_setting( $key, [ 'default' => '#', 'sanitize_callback' => 'esc_url_raw' ] );
        $wp_customize->add_control( $key, [ 'label' => $label, 'section' => 'travzo_social', 'type' => 'url' ] );
    }

    // ── SECTION: Header ───────────────────────────────────────────────────────
    $wp_customize->add_section( 'travzo_header', [
        'title' => 'Header Settings',
        'panel' => 'travzo_panel',
    ] );
    $wp_customize->add_setting( 'travzo_utility_text', [
        'default'           => "Tamil Nadu's Most Trusted Travel Partner",
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'travzo_utility_text', [
        'label'   => 'Utility Bar Text',
        'section' => 'travzo_header',
        'type'    => 'text',
    ] );

    // ── SECTION: Footer ───────────────────────────────────────────────────────
    $wp_customize->add_section( 'travzo_footer', [
        'title' => 'Footer Settings',
        'panel' => 'travzo_panel',
    ] );
    $footer_fields = [
        'travzo_footer_tagline'   => 'Footer Tagline',
        'travzo_footer_address'   => 'Footer Address',
        'travzo_footer_hours'     => 'Footer Hours',
        'travzo_footer_copyright' => 'Copyright Text',
    ];
    foreach ( $footer_fields as $key => $label ) {
        $wp_customize->add_setting( $key, [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $key, [ 'label' => $label, 'section' => 'travzo_footer', 'type' => 'text' ] );
    }

    // ── SECTION: Homepage Hero ────────────────────────────────────────────────
    $wp_customize->add_section( 'travzo_hero', [
        'title' => 'Homepage - Hero Section',
        'panel' => 'travzo_panel',
    ] );
    $hero_text_fields = [
        'travzo_hero_badge'     => 'Badge Text',
        'travzo_hero_heading'   => 'Main Heading',
        'travzo_hero_subtext'   => 'Sub Text',
        'travzo_hero_btn1_text' => 'Primary Button Text',
        'travzo_hero_btn1_url'  => 'Primary Button URL',
        'travzo_hero_btn2_text' => 'Secondary Button Text',
        'travzo_hero_btn2_url'  => 'Secondary Button URL',
    ];
    foreach ( $hero_text_fields as $key => $label ) {
        $wp_customize->add_setting( $key, [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $key, [ 'label' => $label, 'section' => 'travzo_hero', 'type' => 'text' ] );
    }
    $wp_customize->add_setting( 'travzo_hero_image', [ 'default' => '', 'sanitize_callback' => 'esc_url_raw' ] );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'travzo_hero_image', [
        'label'   => 'Hero Background Image',
        'section' => 'travzo_hero',
    ] ) );

    // ── SECTION: Homepage Stats ───────────────────────────────────────────────
    $wp_customize->add_section( 'travzo_stats', [
        'title' => 'Homepage - Stats Bar',
        'panel' => 'travzo_panel',
    ] );
    for ( $i = 1; $i <= 4; $i++ ) {
        $wp_customize->add_setting( "travzo_stat_{$i}_number", [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( "travzo_stat_{$i}_number", [ 'label' => "Stat {$i} Number (e.g. 500+)", 'section' => 'travzo_stats', 'type' => 'text' ] );
        $wp_customize->add_setting( "travzo_stat_{$i}_label", [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( "travzo_stat_{$i}_label", [ 'label' => "Stat {$i} Label (e.g. Happy Travellers)", 'section' => 'travzo_stats', 'type' => 'text' ] );
    }

    // ── SECTION: Homepage About Snippet ──────────────────────────────────────
    $wp_customize->add_section( 'travzo_about_snippet', [
        'title' => 'Homepage - About Snippet',
        'panel' => 'travzo_panel',
    ] );
    $about_text_fields = [
        'travzo_about_label'   => 'Section Label',
        'travzo_about_heading' => 'Heading',
        'travzo_about_text'    => 'Body Text',
        'travzo_about_feat1'   => 'Feature 1',
        'travzo_about_feat2'   => 'Feature 2',
        'travzo_about_feat3'   => 'Feature 3',
    ];
    foreach ( $about_text_fields as $key => $label ) {
        $wp_customize->add_setting( $key, [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $key, [ 'label' => $label, 'section' => 'travzo_about_snippet', 'type' => 'text' ] );
    }
    $wp_customize->add_setting( 'travzo_about_image', [ 'default' => '', 'sanitize_callback' => 'esc_url_raw' ] );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'travzo_about_image', [
        'label'   => 'About Section Image',
        'section' => 'travzo_about_snippet',
    ] ) );

    // ── SECTION: Newsletter ───────────────────────────────────────────────────
    $wp_customize->add_section( 'travzo_newsletter', [
        'title' => 'Homepage - Newsletter',
        'panel' => 'travzo_panel',
    ] );
    $wp_customize->add_setting( 'travzo_newsletter_heading', [
        'default'           => 'Get Travel Deals in Your Inbox',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'travzo_newsletter_heading', [
        'label'   => 'Heading',
        'section' => 'travzo_newsletter',
        'type'    => 'text',
    ] );
    $wp_customize->add_setting( 'travzo_newsletter_subtext', [
        'default'           => 'Subscribe for exclusive offers.',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'travzo_newsletter_subtext', [
        'label'   => 'Subtext',
        'section' => 'travzo_newsletter',
        'type'    => 'text',
    ] );
} );

// ══════════════════════════════════════════════════════════════════════════════
// GLOBAL HELPERS
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Get a Customizer setting value with optional fallback.
 */
function travzo_get( $key, $fallback = '' ) {
    $val = get_theme_mod( $key, '' );
    return ( $val !== '' ) ? $val : $fallback;
}

/**
 * Parse a pipe-delimited textarea into an array of arrays.
 * Each line becomes an array; columns are split by |.
 *
 * @param string $text      Raw textarea value.
 * @param int    $num_cols  Expected number of columns (pads short rows with '').
 * @return array
 */
function travzo_parse_lines( $text, $num_cols = 2 ) {
    if ( empty( $text ) ) return [];
    $lines  = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $text ) ) );
    $result = [];
    foreach ( $lines as $line ) {
        if ( $line === '' ) continue;
        $parts = array_map( 'trim', explode( '|', $line ) );
        while ( count( $parts ) < $num_cols ) {
            $parts[] = '';
        }
        $result[] = $parts;
    }
    return $result;
}

/**
 * Get hero data for inner page templates.
 *
 * @param int $post_id
 * @return array { image, heading, subtext }
 */
function travzo_get_hero( $post_id ) {
    return [
        'image'   => get_post_meta( $post_id, '_hero_image',   true ),
        'heading' => get_post_meta( $post_id, '_hero_heading', true ),
        'subtext' => get_post_meta( $post_id, '_hero_subtext', true ),
    ];
}

/**
 * Legacy helper – kept for backwards compatibility.
 * Without ACF this always returns ''.
 */
function travzo_get_option( $field ) {
    return '';
}

// ══════════════════════════════════════════════════════════════════════════════
// META BOXES – PACKAGE POST TYPE
// ══════════════════════════════════════════════════════════════════════════════
add_action( 'add_meta_boxes', function () {
    add_meta_box( 'travzo_package_details', 'Package Details',
        'travzo_package_details_cb', 'package', 'normal', 'high' );
    add_meta_box( 'travzo_package_content', 'Package Content (Itinerary, Inclusions, Hotels)',
        'travzo_package_content_cb', 'package', 'normal', 'default' );
    add_meta_box( 'travzo_package_pricing', 'Package Pricing',
        'travzo_package_pricing_cb', 'package', 'normal', 'default' );
} );

function travzo_package_details_cb( $post ) {
    wp_nonce_field( 'travzo_package_save', 'travzo_package_nonce' );
    $fields = [
        '_package_type'         => [ 'label' => 'Package Type', 'type' => 'select', 'options' => [ 'Group Tour', 'Honeymoon', 'Solo Trip', 'Devotional', 'Destination Wedding', 'International' ] ],
        '_package_price'        => [ 'label' => 'Starting Price (numbers only, e.g. 15000)', 'type' => 'text' ],
        '_package_duration'     => [ 'label' => 'Duration (e.g. 4 Nights / 5 Days)', 'type' => 'text' ],
        '_package_destinations' => [ 'label' => 'Destinations Covered', 'type' => 'text' ],
        '_package_group_size'   => [ 'label' => 'Group Size (e.g. 2-15 People)', 'type' => 'text' ],
    ];
    foreach ( $fields as $key => $field ) {
        $val = get_post_meta( $post->ID, $key, true );
        echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">' . esc_html( $field['label'] ) . '</label>';
        if ( $field['type'] === 'select' ) {
            echo '<select name="' . esc_attr( $key ) . '" style="width:100%">';
            foreach ( $field['options'] as $opt ) {
                echo '<option value="' . esc_attr( $opt ) . '"' . selected( $val, $opt, false ) . '>' . esc_html( $opt ) . '</option>';
            }
            echo '</select>';
        } else {
            echo '<input type="text" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '" style="width:100%">';
        }
        echo '</p>';
    }
}

function travzo_package_content_cb( $post ) {
    $fields = [
        '_package_highlights' => [
            'label' => 'Package Highlights',
            'help'  => 'One highlight per line. Example:<br>Expert local guides<br>All meals included<br>Airport transfers',
            'rows'  => 6,
        ],
        '_package_inclusions' => [
            'label' => "Inclusions (What's Included)",
            'help'  => 'One item per line.',
            'rows'  => 6,
        ],
        '_package_exclusions' => [
            'label' => "Exclusions (What's Not Included)",
            'help'  => 'One item per line.',
            'rows'  => 6,
        ],
        '_package_itinerary' => [
            'label' => 'Day by Day Itinerary',
            'help'  => 'One day per line in this format:<br><strong>Day 1: Arrival | Arrive at airport, transfer to hotel, welcome dinner</strong>',
            'rows'  => 10,
        ],
        '_package_hotels' => [
            'label' => 'Hotel Details',
            'help'  => 'One hotel per line: <strong>Hotel Name | Stars (3/4/5) | Location | Room Type</strong>',
            'rows'  => 5,
        ],
    ];
    foreach ( $fields as $key => $field ) {
        $val = get_post_meta( $post->ID, $key, true );
        echo '<p>';
        echo '<label style="font-weight:600;display:block;margin-bottom:4px">' . esc_html( $field['label'] ) . '</label>';
        echo '<small style="color:#666;display:block;margin-bottom:6px">' . $field['help'] . '</small>';
        echo '<textarea name="' . esc_attr( $key ) . '" rows="' . intval( $field['rows'] ) . '" style="width:100%">' . esc_textarea( $val ) . '</textarea>';
        echo '</p>';
    }
}

function travzo_package_pricing_cb( $post ) {
    $pricing_fields = [
        '_price_standard_twin'   => 'Standard Room - Twin Sharing (₹)',
        '_price_standard_triple' => 'Standard Room - Triple Sharing (₹)',
        '_price_deluxe_twin'     => 'Deluxe Room - Twin Sharing (₹)',
        '_price_deluxe_triple'   => 'Deluxe Room - Triple Sharing (₹)',
        '_price_premium_twin'    => 'Premium Room - Twin Sharing (₹)',
        '_price_premium_triple'  => 'Premium Room - Triple Sharing (₹)',
        '_price_child_bed'       => 'Child with Extra Bed (₹)',
        '_price_child_no_bed'    => 'Child without Extra Bed (₹)',
    ];
    echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">';
    foreach ( $pricing_fields as $key => $label ) {
        $val = get_post_meta( $post->ID, $key, true );
        echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">' . esc_html( $label ) . '</label>';
        echo '<input type="text" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '" placeholder="e.g. 25000" style="width:100%"></p>';
    }
    echo '</div>';
}

add_action( 'save_post_package', function ( $post_id ) {
    if ( ! isset( $_POST['travzo_package_nonce'] ) ) return;
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['travzo_package_nonce'] ) ), 'travzo_package_save' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    $all_fields = [
        '_package_type', '_package_price', '_package_duration',
        '_package_destinations', '_package_group_size',
        '_package_highlights', '_package_inclusions', '_package_exclusions',
        '_package_itinerary', '_package_hotels',
        '_price_standard_twin', '_price_standard_triple',
        '_price_deluxe_twin', '_price_deluxe_triple',
        '_price_premium_twin', '_price_premium_triple',
        '_price_child_bed', '_price_child_no_bed',
    ];
    foreach ( $all_fields as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_post_meta( $post_id, $field, sanitize_textarea_field( wp_unslash( $_POST[ $field ] ) ) );
        }
    }
} );

// ══════════════════════════════════════════════════════════════════════════════
// META BOXES – PAGE TEMPLATES
// ══════════════════════════════════════════════════════════════════════════════
add_action( 'add_meta_boxes', function () {
    add_meta_box( 'travzo_page_hero',             'Page Hero Section',                      'travzo_page_hero_cb',             'page', 'normal', 'high' );
    add_meta_box( 'travzo_homepage_testimonials', 'Homepage – Testimonials',                 'travzo_homepage_testimonials_cb', 'page', 'normal', 'default' );
    add_meta_box( 'travzo_homepage_tiles',        'Homepage – Package Tiles',                'travzo_homepage_tiles_cb',        'page', 'normal', 'default' );
    add_meta_box( 'travzo_about_content',         'About Page Content',                      'travzo_about_content_cb',         'page', 'normal', 'high' );
    add_meta_box( 'travzo_contact_content',       'Contact Page – Branch Offices',           'travzo_contact_content_cb',       'page', 'normal', 'default' );
    add_meta_box( 'travzo_faq_content',           'FAQ Content',                             'travzo_faq_content_cb',           'page', 'normal', 'high' );
    add_meta_box( 'travzo_media_content',         'Media Page – Videos & Press',             'travzo_media_content_cb',         'page', 'normal', 'default' );
} );

// Show only relevant meta boxes per page/template
add_action( 'do_meta_boxes', function () {
    global $post;
    if ( ! $post ) return;

    $template  = get_page_template_slug( $post->ID );
    $is_front  = ( (int) $post->ID === (int) get_option( 'page_on_front' ) );
    $is_inner  = in_array( $template, [ 'page-about.php', 'page-contact.php', 'page-faq.php', 'page-media.php' ], true );

    if ( ! $is_front ) {
        remove_meta_box( 'travzo_homepage_testimonials', 'page', 'normal' );
        remove_meta_box( 'travzo_homepage_tiles',        'page', 'normal' );
    }
    if ( $template !== 'page-about.php' ) {
        remove_meta_box( 'travzo_about_content', 'page', 'normal' );
    }
    if ( $template !== 'page-contact.php' ) {
        remove_meta_box( 'travzo_contact_content', 'page', 'normal' );
    }
    if ( $template !== 'page-faq.php' ) {
        remove_meta_box( 'travzo_faq_content', 'page', 'normal' );
    }
    if ( $template !== 'page-media.php' ) {
        remove_meta_box( 'travzo_media_content', 'page', 'normal' );
    }
    if ( $is_front || ! $is_inner ) {
        remove_meta_box( 'travzo_page_hero', 'page', 'normal' );
    }
} );

function travzo_page_hero_cb( $post ) {
    wp_nonce_field( 'travzo_page_save', 'travzo_page_nonce' );
    $hero_image   = get_post_meta( $post->ID, '_hero_image',   true );
    $hero_heading = get_post_meta( $post->ID, '_hero_heading', true );
    $hero_subtext = get_post_meta( $post->ID, '_hero_subtext', true );
    ?>
    <p>
        <label style="font-weight:600;display:block;margin-bottom:4px">Hero Background Image URL</label>
        <input type="url" name="_hero_image" value="<?php echo esc_attr( $hero_image ); ?>"
               placeholder="https://… paste image URL or use Upload" style="width:calc(100% - 110px);margin-right:8px">
        <a href="#" onclick="travzoMediaUpload('_hero_image');return false;" class="button">Upload Image</a>
    </p>
    <p>
        <label style="font-weight:600;display:block;margin-bottom:4px">Page Heading</label>
        <input type="text" name="_hero_heading" value="<?php echo esc_attr( $hero_heading ); ?>" style="width:100%">
    </p>
    <p>
        <label style="font-weight:600;display:block;margin-bottom:4px">Page Subtext</label>
        <input type="text" name="_hero_subtext" value="<?php echo esc_attr( $hero_subtext ); ?>" style="width:100%">
    </p>
    <script>
    function travzoMediaUpload(fieldName) {
        var frame = wp.media({ title: 'Select Image', button: { text: 'Use Image' }, multiple: false });
        frame.on('select', function () {
            var att = frame.state().get('selection').first().toJSON();
            document.querySelector('input[name="' + fieldName + '"]').value = att.url;
        });
        frame.open();
    }
    </script>
    <?php
}

function travzo_homepage_testimonials_cb( $post ) {
    $val = get_post_meta( $post->ID, '_testimonials', true );
    echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">Testimonials</label>';
    echo '<small style="color:#666;display:block;margin-bottom:8px">One testimonial per line. Format: <strong>Customer Name | Trip Taken | Quote text</strong><br>';
    echo 'Example: Priya &amp; Arjun | Maldives Honeymoon | Travzo made our trip magical!</small>';
    echo '<textarea name="_testimonials" rows="8" style="width:100%">' . esc_textarea( $val ) . '</textarea></p>';
}

function travzo_homepage_tiles_cb( $post ) {
    $val = get_post_meta( $post->ID, '_package_tiles', true );
    echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">Package Category Tiles</label>';
    echo '<small style="color:#666;display:block;margin-bottom:8px">One tile per line. Format: <strong>Tile Name | Package Count | URL | Image URL (optional)</strong><br>';
    echo 'Example: Group Tours | 12 Packages | /packages?type=Group+Tour | https://...</small>';
    echo '<textarea name="_package_tiles" rows="8" style="width:100%">' . esc_textarea( $val ) . '</textarea></p>';
}

function travzo_about_content_cb( $post ) {
    wp_nonce_field( 'travzo_page_save', 'travzo_page_nonce' );
    $fields = [
        '_about_story_heading'  => [ 'label' => 'Our Story Heading', 'type' => 'text' ],
        '_about_story_text'     => [ 'label' => 'Our Story Text',    'type' => 'textarea', 'rows' => 8 ],
        '_about_story_image'    => [ 'label' => 'Story Image URL',   'type' => 'url' ],
        '_about_team'           => [
            'label' => 'Team Members',
            'type'  => 'textarea',
            'rows'  => 6,
            'help'  => 'One member per line. Format: <strong>Name | Role | Photo URL | Bio</strong>',
        ],
        '_about_awards'         => [
            'label' => 'Awards & Achievements',
            'type'  => 'textarea',
            'rows'  => 6,
            'help'  => 'One award per line. Format: <strong>Award Name | Year | Image URL</strong>',
        ],
        '_about_accreditations' => [
            'label' => 'Accreditation Partners',
            'type'  => 'textarea',
            'rows'  => 4,
            'help'  => 'One per line. Format: <strong>Name | Logo URL</strong>',
        ],
    ];
    foreach ( $fields as $key => $field ) {
        $val = get_post_meta( $post->ID, $key, true );
        echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">' . esc_html( $field['label'] ) . '</label>';
        if ( ! empty( $field['help'] ) ) {
            echo '<small style="color:#666;display:block;margin-bottom:6px">' . $field['help'] . '</small>';
        }
        if ( $field['type'] === 'textarea' ) {
            echo '<textarea name="' . esc_attr( $key ) . '" rows="' . intval( $field['rows'] ?? 4 ) . '" style="width:100%">' . esc_textarea( $val ) . '</textarea>';
        } else {
            echo '<input type="' . esc_attr( $field['type'] ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '" style="width:100%">';
        }
        echo '</p>';
    }
}

function travzo_contact_content_cb( $post ) {
    $val = get_post_meta( $post->ID, '_branches', true );
    echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">Branch Offices</label>';
    echo '<small style="color:#666;display:block;margin-bottom:8px">One branch per line. Format: <strong>City | Address | Phone</strong><br>';
    echo 'Example: Coimbatore | 123 Avinashi Road, Peelamedu 641004 | +91 98765 43210</small>';
    echo '<textarea name="_branches" rows="10" style="width:100%">' . esc_textarea( $val ) . '</textarea></p>';
}

function travzo_faq_content_cb( $post ) {
    $val = get_post_meta( $post->ID, '_faqs', true );
    echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">FAQs</label>';
    echo '<small style="color:#666;display:block;margin-bottom:8px">One FAQ per line. Format: <strong>Question | Answer</strong><br>';
    echo 'Example: How do I book a package? | Fill the enquiry form and we will contact you within 24 hours.</small>';
    echo '<textarea name="_faqs" rows="15" style="width:100%">' . esc_textarea( $val ) . '</textarea></p>';
}

function travzo_media_content_cb( $post ) {
    $videos_val = get_post_meta( $post->ID, '_media_videos', true );
    $press_val  = get_post_meta( $post->ID, '_media_press',  true );
    $awards_val = get_post_meta( $post->ID, '_media_awards', true );

    echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">Videos</label>';
    echo '<small style="color:#666;display:block;margin-bottom:8px">One per line. Format: <strong>Title | YouTube URL | Thumbnail URL (optional)</strong></small>';
    echo '<textarea name="_media_videos" rows="6" style="width:100%">' . esc_textarea( $videos_val ) . '</textarea></p>';

    echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">Press Coverage</label>';
    echo '<small style="color:#666;display:block;margin-bottom:8px">One per line. Format: <strong>Publication | Headline | Date | Article URL</strong></small>';
    echo '<textarea name="_media_press" rows="6" style="width:100%">' . esc_textarea( $press_val ) . '</textarea></p>';

    echo '<p><label style="font-weight:600;display:block;margin-bottom:4px">Awards</label>';
    echo '<small style="color:#666;display:block;margin-bottom:8px">One per line. Format: <strong>Award Title | Year | Awarding Body | Image URL</strong></small>';
    echo '<textarea name="_media_awards" rows="6" style="width:100%">' . esc_textarea( $awards_val ) . '</textarea></p>';
}

// Save all page meta
add_action( 'save_post_page', function ( $post_id ) {
    if ( ! isset( $_POST['travzo_page_nonce'] ) ) return;
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['travzo_page_nonce'] ) ), 'travzo_page_save' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    $page_fields = [
        '_hero_image', '_hero_heading', '_hero_subtext',
        '_testimonials', '_package_tiles',
        '_about_story_heading', '_about_story_text', '_about_story_image',
        '_about_team', '_about_awards', '_about_accreditations',
        '_branches', '_faqs',
        '_media_videos', '_media_press', '_media_awards',
    ];
    foreach ( $page_fields as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_post_meta( $post_id, $field, sanitize_textarea_field( wp_unslash( $_POST[ $field ] ) ) );
        }
    }
} );

// ══════════════════════════════════════════════════════════════════════════════
// WPFORMS HELPER
// ══════════════════════════════════════════════════════════════════════════════
/**
 * Render a WPForms form or fall back to custom HTML.
 *
 * @param int|string $wpforms_id       WPForms form ID.
 * @param string     $fallback_form_html Raw HTML fallback.
 */
function travzo_render_form( $wpforms_id, $fallback_form_html ) {
    if ( function_exists( 'wpforms' ) && $wpforms_id ) {
        echo do_shortcode( '[wpforms id="' . intval( $wpforms_id ) . '"]' );
    } else {
        echo $fallback_form_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}
